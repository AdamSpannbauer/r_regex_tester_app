globalVariables(".")

