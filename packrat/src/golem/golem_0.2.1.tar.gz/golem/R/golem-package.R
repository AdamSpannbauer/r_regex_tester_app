#' A package for building Shiny App
#' 
#' Read more about building big shiny apps at [https://thinkr-open.github.io/building-shiny-apps-workflow/](https://thinkr-open.github.io/building-shiny-apps-workflow/).
#'
#' @docType package
#' @name golem
"_PACKAGE"
