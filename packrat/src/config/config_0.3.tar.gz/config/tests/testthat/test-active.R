
test_that("is_active can be used to test the active configuration", {
  expect_true(config::is_active("default"))
})
