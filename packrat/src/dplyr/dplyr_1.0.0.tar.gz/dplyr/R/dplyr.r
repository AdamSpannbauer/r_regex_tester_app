#' @description
#' To learn more about dplyr, start with the vignettes:
#' `browseVignettes(package = "dplyr")`
#' @useDynLib dplyr, .registration = TRUE
#' @keywords internal
#' @import rlang
#' @importFrom glue glue glue_collapse glue_data
#' @importFrom stats setNames update
#' @importFrom utils head tail
#' @importFrom methods is
#' @importFrom lifecycle deprecated
"_PACKAGE"
