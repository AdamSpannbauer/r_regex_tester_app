expect_no_error <- function(object, ...) {
  expect_error(object, NA, ...)
}
