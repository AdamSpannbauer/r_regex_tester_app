# attempt 0.3.1

* `discretly()` is now aliased `discreetly`

# attempt 0.3.0

* New `is_try_error()` function that tests if an object is of class "try-error".
* New `on_error()` function, for adding a local error handler.
* New `discretly()` function, for removing warnings and message.

# attempt 0.2.1

* Bug fix regarding try_catch and variables
* Two new functions: without_message and without_warning

# attempt 0.2.0

* Bug fix and performance optimisation
* Two new functions: with_message and with_warning

# attempt 0.1.1

* 2018-01-10 : small breaking change in functions. If you call functions with no arg (like `curl::has_internet`), you can't specify "." as first argument anymore - this use of "." is no longer supported. Pass this function as .x.

# attempt 0.1.0

* 2017-12-21 : ready to be used 

# trycatchit 0.0.0.9000

* 2017-12-10 : first stable version

* 2017-12-07 : First commit 

* Added a `NEWS.md` file to track changes to the package.



