library(testthat)
library(pkgbuild)

test_check("pkgbuild")
